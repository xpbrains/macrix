﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Macrix.App.Validation
{
    [AttributeUsage(AttributeTargets.Property)]
    public class BirthDateAttribute : ValidationAttribute
    {
        public BirthDateAttribute()
        {
        }

        public override bool IsValid(object value)
        {
            try
            {
                var dt = (DateTime)value;
                return dt > default(DateTime) && dt < DateTime.Now;
            }
            catch (Exception)
            {
                return false;
            }
            
        }
    }
}
