﻿using Macrix.App.ViewModel;
using System.Windows;

namespace Macrix.App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow(PeopleListViewModel viewModel)
        {
            InitializeComponent();
            ViewModel = viewModel;
        }

        public PeopleListViewModel ViewModel { get; set; }
              
    }
}
