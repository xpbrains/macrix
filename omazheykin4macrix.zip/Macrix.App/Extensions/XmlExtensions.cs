﻿using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Macrix.App.Extensions
{
    public static class XmlExtensions
    {
        public static T FromXml<T>(this XmlDocument document)
            where T : class
        {
            XmlReader reader = new XmlNodeReader(document);
            var serializer = new XmlSerializer(typeof(T));
            T result = (T)serializer.Deserialize(reader);
            return result;
        }
        public static void ToXml<T>(T anyobject, string xmlFilePath)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(anyobject.GetType());

            using (StreamWriter writer = new StreamWriter(xmlFilePath))
            {
                xmlSerializer.Serialize(writer, anyobject);
            }
        }
    }
}
