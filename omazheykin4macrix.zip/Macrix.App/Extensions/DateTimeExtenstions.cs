﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Macrix.App.Extensions
{
    public static class DateTimeExtenstions
    {
        public static int CalculateAge(this DateTime BirthDate)
        {
            int YearsPassed = DateTime.Now.Year - BirthDate.Year;
            if (DateTime.Now.Month < BirthDate.Month
                || (DateTime.Now.Month == BirthDate.Month && DateTime.Now.Day < BirthDate.Day))
            {
                YearsPassed--;
            }
            return YearsPassed;
        }
    }
}
