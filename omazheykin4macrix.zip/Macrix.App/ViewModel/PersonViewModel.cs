﻿using Macrix.App.Extensions;
using Macrix.App.Validation;
using Macrix.App.ViewModel;
using System;
using System.ComponentModel.DataAnnotations;

namespace Macrix.App.Model
{
    public class PersonViewModel : ValidatableVieModel
    {
        public static PersonViewModel New()
        {
            return new PersonViewModel
            {
                FirstName = "N/A",
                LastName = "N/A",
                StreetName = "N/A",
                HouseNumber = "N/A",
                PhoneNumber= "N/A",
                ApartmentNumber = "N/A",
                PostalCode = "N/A",
                Town = "N/A",
                DateOfBirth = DateTime.Now

            };
        }

        public PersonViewModel()
        {
        }

        [Required]
        public string FirstName { get => firstName; set => SetValue(ref firstName, nameof(FirstName), value); }

        [Required]
        public string LastName { get => lastName; set => SetValue(ref lastName, nameof(LastName), value); }

        [Required]
        public string StreetName { get => streetName; set => SetValue(ref streetName, nameof(StreetName), value); }

        [Required]
        public string PostalCode { get => postalCode; set => SetValue(ref postalCode, nameof(PostalCode), value); }
        [Required]
        public string Town { get => town; set => SetValue(ref town, nameof(Town), value); }

        [Required]
        public string HouseNumber { get => houseNumber; set => SetValue(ref houseNumber, nameof(HouseNumber), value); }
        
        [Required]
        public string PhoneNumber { get => phoneNumber; set => SetValue(ref phoneNumber, nameof(PhoneNumber), value); }

        public string ApartmentNumber { get => apartmentNumber; set => SetValue(ref apartmentNumber, nameof(ApartmentNumber), value); }

        [Required]
        [BirthDate(ErrorMessage = "Date must be after or equal to current date")]
        public DateTime DateOfBirth
        {
            get => dateOfBirth; set
            {
                SetValue(ref dateOfBirth, nameof(DateOfBirth), value);
                NotifyPropertyChanged(nameof(Age));
            }
        }
        public int Age
        {
            get
            {
                return DateOfBirth.CalculateAge();
            }
        }

        private string firstName;
        private string lastName;
        private string streetName;
        private string houseNumber;
        private string apartmentNumber;
        private DateTime dateOfBirth;
        private string postalCode;
        private string town;
        private string phoneNumber;
    }
}
