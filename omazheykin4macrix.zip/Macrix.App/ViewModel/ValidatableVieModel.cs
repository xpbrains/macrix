﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Macrix.App.ViewModel
{
    public class ValidatableVieModel : BindableViewModel, INotifyDataErrorInfo
    {
        private readonly Dictionary<string, List<string>> validationErrors = new Dictionary<string, List<string>>();

        public bool HasErrors => validationErrors.Any();

        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;
        
        public IEnumerable GetErrors(string propertyName)
        {
            IEnumerable result = null;
            if (!string.IsNullOrWhiteSpace(propertyName))
            {
                result = validationErrors.ContainsKey(propertyName) ? validationErrors[propertyName] : null;
            }

            return result;
        }

        protected override void SetValue<T>(ref T propertyValue, string propertyName, T newValue)
        {
            base.SetValue(ref propertyValue, propertyName, newValue);
            ValidateProperty(propertyName, newValue);
        }

        private void ValidateProperty<T>(string propertyName, T newValue)
        {
            var result = new List<ValidationResult>();

            ValidationContext context = new ValidationContext(this) { MemberName = propertyName };
            Validator.TryValidateProperty(newValue, context, result);

            if (result.Any())
            {
                validationErrors[propertyName] = result.Select(c => c.ErrorMessage).ToList();
            }
            else
            {
                validationErrors.Remove(propertyName);
            }
            ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
        }
    }
}
