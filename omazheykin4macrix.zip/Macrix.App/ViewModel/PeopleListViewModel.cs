﻿using Macrix.App.Command;
using Macrix.App.Data;
using Macrix.App.Extensions;
using Macrix.App.Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;

namespace Macrix.App.ViewModel
{
    public class PeopleListViewModel : BindableViewModel
    {
        const string XmlFileName = "people.xml";

        public PeopleListViewModel(Cities cities, XmlFileLoader xmlFileLoader)
        {
            XmlFileLoader = xmlFileLoader;
            changed = false;
            Cities = cities.GetAll();
            SetupCommands();
            LoadFile();
        }

        public List<string> Cities { get; private set; }
        public BindingList<PersonViewModel> PeopleList
        {
            get => peopleList;
            set
            {
                SetValue(ref peopleList, nameof(PeopleList), value, Unsubscribe, Subscribe);
            }
        }
        public ICommand CancelCommand { get; private set; }
        public ICommand DeleteCommand { get; private set; }
        public ICommand AddCommand { get; private set; }
        public ICommand SaveCommand { get; private set; }
        private void LoadFile()
        {
            PeopleList = new BindingList<PersonViewModel>();
            List<PersonViewModel> items = XmlFileLoader.Load<List<PersonViewModel>>(XmlFileName);
            try
            {
                if (items != null)
                {
                    PeopleList = new BindingList<PersonViewModel>(items);
                    changed = false;
                }
            }
            catch (System.Exception exc)
            {
                throw new System.ApplicationException("Can not load xml file",exc) ;
            }
        }

        private void SetupCommands()
        {
            AddCommand = new RelayCommand(_ => PeopleList?.Add(PersonViewModel.New()));
            DeleteCommand = new RelayCommand(person => DeleteItem(person));
            SaveCommand = new RelayCommand(_ =>
            {
                XmlFileLoader.Save(PeopleList, XmlFileName); LoadFile();
            }, _ => changed && !PeopleList.Any(p => p.HasErrors));
            CancelCommand = new RelayCommand(_ => LoadFile(), _ => changed);
        }

        private void DeleteItem(object person)
        {
            int index = PeopleList.IndexOf(person as PersonViewModel);
            if (index > -1 && index < PeopleList.Count)
            {
                PeopleList.RemoveAt(index);
            }
        }
        private void Subscribe(BindingList<PersonViewModel> propertyValue)
        {
            if (propertyValue != null)
            {
                propertyValue.ListChanged += OnChanged;
                propertyValue.AddingNew += OnAddedNew;
            }
        }
        private void Unsubscribe(BindingList<PersonViewModel> propertyValue)
        {
            if (propertyValue != null)
            {
                propertyValue.ListChanged -= OnChanged;
                propertyValue.AddingNew -= OnAddedNew;
            }
        }
        private void OnChanged(object sender, ListChangedEventArgs e)
        {
            // we just track the changes on bindabke list
            changed = true;
        }
        private void OnAddedNew(object sender, AddingNewEventArgs e)
        {
            // just set true fir simplicity
            changed = true;
        }
        private BindingList<PersonViewModel> peopleList;
        private XmlFileLoader XmlFileLoader { get; }
        private bool changed;
    }
}