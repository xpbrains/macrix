﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Macrix.App.ViewModel
{
    public class BindableViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SetValue<T>(ref T propertyValue, string propertyName, T newValue)
        {
            propertyValue = newValue;
            NotifyPropertyChanged(propertyName);
        }
        protected virtual void SetValue<T>(ref T propertyValue, string propertyName, T newValue, Action<T> preAction, Action<T> postAction)
        {
            preAction(propertyValue);
            SetValue(ref propertyValue, propertyName,  newValue);
            postAction(propertyValue);
        }
        

        protected void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
