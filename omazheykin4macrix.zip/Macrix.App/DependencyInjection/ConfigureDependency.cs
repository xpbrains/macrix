﻿using Macrix.App.Data;
using Macrix.App.ViewModel;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Macrix.App.DependancyInjection
{
    public static class ConfigureDependency
    {
        public static IServiceCollection  RegisterServices(this IServiceCollection services)
        {
            services.AddTransient(typeof(MainWindow));
            services.AddTransient(typeof(Cities));
            services.AddTransient(typeof(XmlFileLoader));
            services.AddTransient(typeof(PeopleListViewModel));
            return services;
        }
    }
}
