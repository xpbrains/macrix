﻿using Macrix.App.Extensions;
using System;
using System.IO;
using System.Xml;

namespace Macrix.App.Data
{
    public class XmlFileLoader
    {
        const string MacrixFolder = @"Macrix\Files";
        private readonly string fileLocation;

        public XmlFileLoader()
        {
            fileLocation = Path.Combine(Environment
                .GetFolderPath(Environment.SpecialFolder.UserProfile), MacrixFolder);

            if (!Directory.Exists(fileLocation))
            {
                Directory.CreateDirectory(fileLocation);
            }
        }
        public T Load<T>(string fileName) where T: class
        {
            XmlDocument doc = new XmlDocument();
            string pathToFie = Path.Combine(fileLocation, fileName);
            if (File.Exists(pathToFie))
            {
                doc.Load(pathToFie);
                return doc.FromXml<T>();
            }
            return default;
        }

        public void Save<T>(T items, string fileName)
        {
            string pathToFie = Path.Combine(fileLocation, fileName);
            XmlExtensions.ToXml(items, pathToFie);
        }
    }
}
