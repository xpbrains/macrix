﻿using System.Collections.Generic;

namespace Macrix.App.Data
{
    public class Cities
    {
        public List<string> GetAll()
        {
            return new List<string>
            {
                "Poznan", "Warsaw", "Cracow", "Wroclaw"
            };
        }
    }
}
